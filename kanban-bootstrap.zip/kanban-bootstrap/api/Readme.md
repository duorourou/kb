## Kanban API
This is a simple Kanban api interface for Spring Boot applications.


### Tech

Api uses a number of teches to work properly:

* [Git] - HTML enhanced for web apps!
* [gradle] - awesome web-based text editor
* [docker] - a super fast port of Markdown to JavaScript



### Installation
- install git : https://git-scm.com/book/en/v2/Getting-Started-Installing-Git
- install java 7+  : https://java.com/en/download/help/index_installing.xml
- install gradle 2.3+ : https://docs.gradle.org/current/userguide/installation.html
- install docker : https://docs.docker.com/engine/installation/



### Run

**run locally**
 
    $ ./gradlew build && java -jar build/libs/api-0.1.0.jar
  
**run from docker**
    
- set application image name and tag in build task in build.gradle file
  

    jar {
    	baseName = "api"
    	version = "0.0.1-SNAPSHOT"
    }    


    task buildDocker(type: Docker, dependsOn: build) {
   	    push = false
   	    applicationName = jar.baseName
   	    version = jar.version
   	    dockerfile = file("Dockerfile")
   	    doFirst {
   		    copy {
   			    from jar
   			    into stageDir
   		    }
   	    }
    }     
    
    
- run the gradle task


        $ ./gradlew build buildDocker 

- in the docker session


        $ docker run -p 8999:8999 -t api:latest

### Note
You can use curl in your terminal to test the service 

**curl a get request to get story**
 
    curl http://192.168.99.100:8080/story/0
 
**curl a post request**

    curl -X POST -H "Content-Type: application/json" -d '{"storyName":"0","storyDesc":"Story 0.0","storyPoint":"Story 0 is a 0 point story","storyLabels":["xl","task"],"storyMembers":["Jim","Jobs"]}' 'http://192.168.99.100:8080/story/'



   [Git]: <https://git-scm.com/documentation>
   [gradle]: <https://docs.gradle.org/>
   [docker]: <https://docs.docker.com/>