package com.huawei.controller;

import com.google.gson.Gson;
import com.huawei.ApiApplication;
import com.huawei.bean.Story;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.Arrays;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * Created by xchou on 3/21/16.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {ApiApplication.class})
@WebAppConfiguration
public class StoryControllerTest{

    private MockMvc mockMvc;

    @Autowired
    private StoryController controller;

    @org.junit.Before
    public void setUp() throws Exception {
        mockMvc = MockMvcBuilders.standaloneSetup(controller).build();
    }

    @Test
    @Deprecated
    public void testFindStory() throws Exception {

    }

    @Test
    public void testCreateStory() throws Exception {
        String uri = "/story";
        String requestBody = "{\"storyName\":\"3\",\"storyDesc\":\"Story_3\",\"storyPoint\":\"3 points story\",\"storyLabels\":[\"XXL\",\"story\"],\"storyMembers\":[\"Json\",\"John\",\"Bill\"]}";
        String responseBody = "{\"storyName\":\"3\",\"storyDesc\":\"Story_3\",\"storyPoint\":\"3 points story\",\"storyLabels\":[\"XXL\",\"story\"],\"storyMembers\":[\"Json\",\"John\",\"Bill\"]}";

        mockMvc.perform(
                MockMvcRequestBuilders.post(uri)
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON).content(requestBody))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(content().json(responseBody))
                .andReturn();
    }

    @Test
    public void testUpdateStory() throws Exception {
        String uri = "/story";
        String requestBody = "{\"storyId\":2,\"storyName\":\"3\",\"storyDesc\":\"Story_2\",\"storyPoint\":\"2 points story\",\"storyLabels\":[\"XXL\",\"story\"],\"storyMembers\":[\"Json\",\"John\",\"Bill\"]}";
        String responseBody = "{\"storyId\":2,\"storyName\":\"3\",\"storyDesc\":\"Story_2\",\"storyPoint\":\"2 points story\",\"storyLabels\":[\"XXL\",\"story\"],\"storyMembers\":[\"Json\",\"John\",\"Bill\"]}";

        mockMvc.perform(
                MockMvcRequestBuilders.put(uri)
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON).content(requestBody))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(content().json(responseBody))
                .andReturn();

    }

    @Test(expected = Exception.class)
    public void testUpdateStoryWithoutId() throws Exception {
        String uri = "/story";
        String requestBody = "{\"storyName\":\"3\",\"storyDesc\":\"Story_2\",\"storyPoint\":\"2 points story\",\"storyLabels\":[\"XXL\",\"story\"],\"storyMembers\":[\"Json\",\"John\",\"Bill\"]}";

        mockMvc.perform(
                MockMvcRequestBuilders.put(uri)
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON).content(requestBody))
                .andExpect(status().is5xxServerError());

    }
}