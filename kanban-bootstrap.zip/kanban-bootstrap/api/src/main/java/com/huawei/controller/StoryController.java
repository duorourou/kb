package com.huawei.controller;

import com.huawei.bean.Story;
import com.huawei.service.StoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Objects;

/**
 * Created by xchou on 3/21/16.
 */
@RestController
@RequestMapping("/story")
public class StoryController {

    @Autowired
    private StoryService storyService;

    @RequestMapping(value = "/{storyId}" , method = RequestMethod.GET)
    public Story findStory(@PathVariable(value = "storyId" ) String storyId){
        return storyService.findStoryById(storyId);
    }

    @RequestMapping(method = RequestMethod.PUT, produces = "application/json")
    public Story createStory(@RequestBody Story storyIn) throws Exception {
        return storyService.update(storyIn);
    }

    @RequestMapping(method = RequestMethod.POST, produces = "application/json")
    public Story updateStory( @RequestBody Story storyIn) throws Exception {
        return storyService.save(storyIn);
    }

}
