package com.huawei.bean;

import java.util.List;

/**
 * Created by xchou on 3/21/16.
 */
public class Story {

    private Long storyId;
    private String storyName;
    private String storyDesc;
    private String storyPoint;
    private List<String> storyLabels;
    private List<String> storyMembers;

    public Story() {
    }

    public Story(String storyName, String storyDesc, String storyPoint) {
        this.storyName = storyName;
        this.storyDesc = storyDesc;
        this.storyPoint = storyPoint;
    }

    public Story(Long storyId, String storyName, String storyDesc, String storyPoint) {
        this.storyId = storyId;
        this.storyName = storyName;
        this.storyDesc = storyDesc;
        this.storyPoint = storyPoint;
    }

    public Long getStoryId() {
        return storyId;
    }

    public void setStoryId(Long storyId) {
        this.storyId = storyId;
    }

    public String getStoryName() {
        return storyName;
    }

    public void setStoryName(String storyName) {
        this.storyName = storyName;
    }

    public String getStoryDesc() {
        return storyDesc;
    }

    public void setStoryDesc(String storyDesc) {
        this.storyDesc = storyDesc;
    }

    public String getStoryPoint() {
        return storyPoint;
    }

    public void setStoryPoint(String storyPoint) {
        this.storyPoint = storyPoint;
    }

    public List<String> getStoryLabels() {
        return storyLabels;
    }

    public void setStoryLabels(List<String> storyLabels) {
        this.storyLabels = storyLabels;
    }

    public List<String> getStoryMembers() {
        return storyMembers;
    }

    public void setStoryMembers(List<String> storyMembers) {
        this.storyMembers = storyMembers;
    }
}
