package com.huawei.service;

import com.huawei.bean.Story;

/**
 * Created by xchou on 3/21/16.
 */
public interface StoryService {

    Story findStoryById(String id);

    Story save(Story id) throws Exception;

    Story update(Story id) throws Exception;
}
