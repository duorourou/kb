package com.huawei.dao;

import com.huawei.bean.Story;
import org.springframework.stereotype.Repository;

import java.util.*;

/**
 * Created by xchou on 3/21/16.
 */
@Repository
public class StoryDAOImpl implements StoryDAO {

    final static Map<String, Story> storyRepo = new HashMap<>();

    static {
        Story story0 = new Story(0L , "0", "Story 0.0", "Story 0 is a 0 point story");
        story0.setStoryMembers(Arrays.asList("Json", "John", "Bill"));
        story0.setStoryLabels(Arrays.asList("XXL", "story"));

        Story story1 = new Story(1L, "1", "Story 1.0", "Story 1 is a 1 point story");
        story0.setStoryMembers(Arrays.asList("Jim", "Jobs"));
        story0.setStoryLabels(Arrays.asList("xl", "task"));

        storyRepo.put("0", story0);
        storyRepo.put("1", story1);
    }

    @Override
    public Story findStoryById(String id) {
        return storyRepo.get(id);
    }

    @Override
    public Story save(Story story) {
        story.setStoryId(Long.valueOf(storyRepo.size()));
        storyRepo.putIfAbsent(String.valueOf(story.getStoryId()), story);
        return story;
    }

    @Override
    public Story update(Story story) {
        storyRepo.put(String.valueOf(story.getStoryId()), story);
        return story;
    }
}
