package com.huawei.service;

import com.huawei.bean.Story;
import com.huawei.dao.StoryDAO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Objects;

/**
 * Created by xchou on 3/21/16.
 */
@Service
public class StoryServiceImpl implements StoryService {

    private final static Logger logger = LoggerFactory.getLogger(StoryServiceImpl.class);

    @Autowired
    StoryDAO storyDAO;

    @Override
    public Story findStoryById(String id) {
        return storyDAO.findStoryById(id);
    }

    @Override
    public Story save(Story storyIn) throws Exception {
        logger.info("0" , storyIn);
        if(Objects.nonNull(storyIn.getStoryId())){
            throw new Exception("Could not save a story with story id.");
        }
        return storyDAO.save(storyIn);
    }

    @Override
    public Story update(Story storyIn) throws Exception{
        logger.info("0" , storyIn);
        if(Objects.isNull(storyIn.getStoryId())){
            throw new Exception("Could not update a story without story id.");
        }
        return storyDAO.update(storyIn);
    }
}
