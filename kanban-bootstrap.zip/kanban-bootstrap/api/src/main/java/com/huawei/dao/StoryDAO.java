package com.huawei.dao;

import com.huawei.bean.Story;

/**
 * Created by xchou on 3/21/16.
 */
public interface StoryDAO {

    Story findStoryById(String id);
    Story save(Story story);
    Story update(Story story);
}
