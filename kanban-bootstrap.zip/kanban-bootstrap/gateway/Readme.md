## Kanban API

Gateway service.

### RUN AS A MAVEN PROJECT

    $ mvn clean install package 
    $ java -jar target/gateway-0.0.1-SNAPSHOT.jar
    
### TEST
    
    Open the url 'http://localhost:8080/api/story/0' in your browser.
    if the browser redirect to http://localhost:8080 then successfully!

### NOTE
    
    if you want to login as a github user : 
        1) add this appliation in 'https://github.com/settings/developers' with login user
        2) "Authorization callback URL" should be the 'http://localhost:8080/'
        3) modify the client-id and client-secret as your accout.
           
