'use strict';

angular.module('kanbanFrontendApp')
  .controller('AboutCtrl', function () {
  });
