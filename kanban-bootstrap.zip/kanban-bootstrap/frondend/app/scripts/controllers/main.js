'use strict';

angular.module('kanbanFrontendApp')
  .controller('MainCtrl', ['$scope', function ($scope) {
    var mainCtrl = this;
    mainCtrl.findCard = function() {
      var cardId = mainCtrl.cardId;
      console.log("cardId: " + cardId);

      // This part should be the API call and put the response json to `storyData`
      $scope.storyData = {
        "storyName": cardId,
        "storyDesc": "Story " + cardId,
        "storyPoint": "Story " + cardId + " is a x point story",
        "storyLabels": [
          "xl",
          "task"
        ],
        "storyMembers": [
          "Jim",
          "Jobs"
        ]
      };
    }
  }]
  );
