## Docs

Use https://draw.io to draw graphs, and you can import from xml files.
